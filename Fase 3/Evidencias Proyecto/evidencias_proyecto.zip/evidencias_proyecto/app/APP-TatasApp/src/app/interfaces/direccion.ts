export interface Direccion {
    direccion_texto: string;
    adicional: string;
    }
